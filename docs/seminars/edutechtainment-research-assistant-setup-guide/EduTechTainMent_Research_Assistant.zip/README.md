# EduTechTainMent Research Librarian, a Claude Skill

An interactive research-methodology assistant that walks a researcher, in any discipline, from a rough idea through to a fully structured, evidence-grounded, submission-ready study protocol. Built as a [Claude Skill](https://docs.claude.com/en/docs/agents-and-tools/agent-skills/overview): interactive by default, critical by default, and treats fabricated citations, invented statistics, guessed database syntax, and invented cost figures as hard failures rather than acceptable shortcuts.

Created and maintained by **EduTechTainMent**. Creator profile and portfolio: https://waga43.github.io/weblog

This repository has gone through three feature releases (**v1 → v2 → v3**), and all three have since been revised twice more: once to add a shared set of methodological-rigour upgrades (critical refinement/devil's-advocate behaviour, an expanded database and framework catalogue, mandatory elicitation of the user's own prior ideas, an expanded statistics-resource base, and a "cite your sources" requirement on every decision), and once to rebrand the skill under the EduTechTainMent name with a dedicated welcome message and a defined voice and style for its outputs. This README explains what each version does, why it exists, and how to pick the right one.

> **Note on installable skill identity**: regardless of the display title shown above, the installable skill's internal identifier (the YAML frontmatter `name` field, required to be lowercase kebab-case by the Skills packaging spec) is `edutechtainment-research-librarian` across all three versions.

---

## Table of Contents

- [Quick decision guide](#quick-decision-guide)
- [What this skill actually does](#what-this-skill-actually-does)
- [Design philosophy (applies to every version)](#design-philosophy-applies-to-every-version)
- [Cross-cutting upgrades applied to all three versions](#cross-cutting-upgrades-applied-to-all-three-versions)
- [Version comparison at a glance](#version-comparison-at-a-glance)
- [v1, Core literature-search and study-design engine](#v1--core-literature-search-and-study-design-engine)
- [v2, Adding literature-grounded SMART objectives](#v2--adding-literature-grounded-smart-objectives)
- [v3, Full protocol lifecycle: feasibility, limitations, and dual IRB-ready protocol + detailed workflow documentation](#v3--full-protocol-lifecycle-feasibility-limitations-and-dual-irb-ready-protocol--detailed-workflow-documentation)
- [Full file structure (v3)](#full-file-structure-v3)
- [Installation](#installation)
- [Requirements / dependencies](#requirements--dependencies)
- [A note on the `description` field across versions](#a-note-on-the-description-field-across-versions)
- [Limitations and disclaimers](#limitations-and-disclaimers)
- [Changelog summary](#changelog-summary)

---

## Quick decision guide

| If you want... | Install |
|---|---|
| Just a database-search-string builder and a PICO-family breakdown helper, with critical pushback on your inputs | **v1** |
| The above, plus help turning a question into rigorous, literature-justified SMART objectives | **v2** |
| The above, plus question brainstorming, realistic feasibility/timeline/cost estimation, an honest limitations critique, and a full IRB-ready protocol *plus* a separate, genuinely detailed workflow documentation (not a condensed summary) | **v3** (recommended for most users) |
| A lightweight tool for a single-session task | **v1** |
| A tool to take you all the way to a submittable, collaborator-ready research protocol | **v3** |
| Something tuned for researchers in lower-resource settings (e.g., Nigeria/Africa) needing realistic cost/timeline planning | **v3** |

If you're not sure: **install v3.** Every capability in v1 and v2 is still present in v3.

---

## What this skill actually does

At its core, this skill turns a conversation into a research-methodology consulting session, one where the "consultant" pushes back on weak inputs rather than rubber-stamping them. A researcher can arrive with anything from a vague topic to a fully-formed hypothesis, and the skill will:

1. Help scope the type of study and discipline.
2. Build or **critically refine** a formal, answerable research question, not just accept whatever is typed in.
3. Break the question down using the correct framework, from a catalogue of eight (PICO, PICOC, PECO, PEO, CoCoPop, SPICE, SPIDER, PCC), selected deliberately and backed by a search for precedent studies that used the same framework.
4. Construct **syntax-validated** search strings for Boolean-query academic databases, and give proper usage guidance for AI-native/semantic discovery tools that don't use Boolean syntax at all.
5. Classify study variables and map them to the statistically correct test, using an **interactive decision-tree conversation** modeled on several verified statistics-selection tools, not just a static lookup table.
6. Produce a verified reading list, every citation checked via full-text or structured metadata retrieval.
7. Assemble a final deliverable document (Markdown / Word / PDF).

Versions 2 and 3 extend this pipeline further, see below.

---

## Design philosophy (applies to every version)

- **Interactive by construction.** The skill stops after every major step, explains *why* a decision was made, and explicitly asks: "Are you satisfied with this, or would you like revisions?" It never assumes silence means approval.
- **Critical by construction, not just interactive.** This is the most significant standing change across all three versions (detailed below): the skill is now instructed to act as a genuine devil's advocate on every user-supplied input, not a passive scribe.
- **Zero tolerance for fabrication.** No invented citations, DOIs, PMIDs, author names, statistics, database syntax, literature "gaps," framework precedents, or (v3) currency figures.
- **Programmatic validation over eyeballing.** Every generated Boolean-syntax search string is run through `scripts/academic_query_validator.py` before being shown to the user.
- **Direct vs. indirect evidence is always distinguished**, and every decision now carries a disclosed "Sources consulted" list.

---

## Cross-cutting upgrades applied to all three versions

The following changes were made identically across v1, v2, and v3, they are not new *steps* so much as new *standing behaviours* that apply throughout whichever version you install.

### 1. Critical refinement, the skill now argues back
Previously, if a user supplied a research question, a framework choice, or a variable, the skill would refine it only if asked. Now, **every** user-supplied input is actively critiqued: genuine strengths are named, genuine weaknesses are explained by mechanism (not just asserted), and a specific evidence-based refinement is proposed. If the user insists on keeping their original choice, the skill must still state the weaknesses plainly and offer concrete mitigations, it can't simply defer and move on. This was added because a skill that only refines on request tends to under-catch exactly the inputs that most need catching: a researcher rarely knows to ask "is my research question flawed?"

### 2. Expanded database catalogue, including AI-native tools
The original four Boolean-syntax database reference files (Google Scholar, PubMed, ScienceDirect, IEEE/Scopus/WoS) are joined by a new **`references/ai-native-search-tools.md`**, covering Consensus, Inciteful, Research Rabbit, and Semantic Scholar's natural-language mode, none of which are Boolean-query engines, so the skill is explicit that these should never be forced through the syntax validator or given fabricated Boolean operators. This file also documents a sensible sequencing (structured Boolean searches first to establish a reproducible evidence base, then Consensus for a directional read, then Inciteful/Research Rabbit for citation-network snowballing from seed papers). It also flags that "Google Labs" is not a verified, standardized academic database name and instructs the skill to ask for clarification rather than invent syntax for it.

### 3. Four more question-framing frameworks, with citation-backed justification
Beyond the original PICO/PICOC/PECO/CoCoPop/SPICE set, `references/frameworks.md` now includes:
- **PEO** (Population, Exposure, Outcome), a comparator-free variant, flagged as inconsistently defined across methodological traditions, with an instruction to verify the applicable convention before presenting it as standard.
- **SPIDER** (Sample, Phenomenon of Interest, Design, Evaluation, Research type), for qualitative/mixed-methods evidence synthesis, with its actual published origin cited (Cooke, Smith & Booth, *Qualitative Health Research*, 2012).
- **PCC** (Population, Concept, Context), the JBI-recommended framework specifically for scoping reviews.

Critically, the skill is now instructed to **search for a precedent**, a real published study in the user's discipline that used the chosen framework for a similar question, and cite it, or say plainly that no verifiable precedent was found. This directly supports academic integrity and cross-study comparability, which was the explicit reason this requirement was added.

### 4. Mandatory elicitation of the user's own ideas before generating
Before producing new content at *any* step, not just the initial research question, the skill must now ask whether the user already has specific ideas they want incorporated. The clearest example: before presenting a variable classification, the skill asks whether the user has already identified specific independent, dependent, or confounding variables. This treats the researcher as a domain expert with prior thinking worth surfacing first, rather than a blank slate, while still applying the critical-refinement principle to whatever they supply.

### 5. Expanded, verified statistics decision-support base
`references/statistical-test-mapping.md` now cross-checks the original UCLA OARC framework against six additional resources the user specifically requested. Three were independently fetched and verified for this update (Julie Pallant's Stats Selection Tool, a 3-question interactive flow; Biostatist's Test Selector, a 5-step progressive questionnaire; INSPECT-LB's Statistical Test Selection Tool, category-first, with real cited methodological references). The UCSD Library guide was verified as a curator page pointing to SAGE, ICPSR, UCLA, and NYU. SAGE Research Methods' page blocked automated access (robots.txt), this is disclosed honestly in the reference file rather than describing content that wasn't actually confirmed. The skill now conducts the statistics step as a short interactive question sequence (research goal → data type → group count → independence → distribution) modeled on the verified tools, rather than presenting a static table cold.

### 6. "Sources consulted" on every decision
Every stop-guardrail across every version now closes with a disclosed list of what was actually searched or cited to reach that decision, extending the pre-existing anti-fabrication commitments into a visible, checkable habit rather than an implicit one.

### 7. Study design nuances explained for every design choice
`references/study-design-requirements.md` is a new file, read whenever the study type is chosen or confirmed in Step 1. For every design, not only RCTs, the skill now explicitly walks through the mandatory, defining requirements (for example, an RCT requires a deliberately administered intervention, genuine random allocation, a comparator arm, and a prospective design; a quasi-experimental design shares the intervention but lacks true randomisation, and comes in several named sub-types such as non-equivalent control group, pre-post, and interrupted time series). It names which requirements the user's described plan already satisfies and which are missing, explains the specific validity threat created by any gap, and offers an evidence-based mitigation, rather than simply applying a design label.

### 8. Explicit MCP-tool-first academic search, with disclosed merits and drawbacks
Before constructing any search strings, the skill now checks what academic-literature MCP connectors (for example a Consensus MCP or a Paper Search MCP) are actually available in the conversation, and prioritises them over a generic web search when present. If none are available, it says so explicitly and asks the user to choose between enabling or installing a connector, or proceeding with `web_search`/`web_fetch`, and honestly lays out the merits and drawbacks of each path (an MCP academic tool is typically more structured, deduplicated, and sometimes gives direct full-text access; web search is universally available but noisier and needs more manual verification) so the choice is genuinely informed rather than assumed.

### 9. Explanations paired with "further reading," not just "sources consulted"
Every stop-guardrail now carries two distinct lists: "Sources consulted" (what was actually searched or cited to reach the decision) and "For further reading" (additional resources so the user can deepen their own understanding of *why* the decision is correct, for example why a particular variable is best treated as the outcome rather than a predictor). The explanation itself must be substantive enough that the user could explain the reasoning to someone else afterwards.

### 10. Mandatory bibliography in every long-form deliverable
Every Workflow Documentation (all versions) and the Study Protocol (v3) must now close with a dedicated Bibliography section listing every source used anywhere in the workflow, each with its DOI or PMID where one exists, noting explicitly which were confirmed accessible as full text rather than abstract-only, and linking directly to open-access versions where possible. A source without a genuine identifier is listed honestly without one; the skill never invents a DOI or PMID to fill a gap.

### 11. Rebrand, welcome message, and a defined voice and style
All three versions were renamed from the generic "Research Librarian" to **EduTechTainMent Research Librarian**. The first time the skill is invoked in any conversation, it now opens with a short welcome block naming its creator, EduTechTainMent's motto ("Over Every Possessor of Knowledge, There is (Some) One (Else) More Knowledgeable"), and a link to the creator's portfolio (https://waga43.github.io/weblog), before proceeding into Step 1.

A dedicated voice and style principle now governs every conversational response and most deliverables: a warm, calm, mentor-style tone that is confident without being hype-driven; British spelling throughout (synthesise, rigour, programme); no em dashes anywhere, replaced with commas, full stops, or hyphens; and a firm rule against inventing citations, paper titles, or study counts. Where literature evidence is genuinely needed, the skill either works from a DOI or PMID the user supplies directly, or uses the MCP-tool-first / web-search-fallback process above.

Crucially, the "no shaming" requirement changes how critiques land, not just how they read: every flagged weakness must first be framed so it feels reasonable and evidence-based, only then followed by its evidence-based cost or implication, and always closed with a concrete, evidence-based way to fix it. In v3, the full Study Protocol document is explicitly carved out of the warm conversational voice: it uses formal, impersonal academic register and a deliberate tense convention (future tense for planned procedures not yet carried out, since a protocol is written before the study happens, and past tense when describing already-published prior literature), while the companion Workflow Documentation keeps the mentor voice throughout. The no-em-dash and British-spelling rules apply to both documents without exception.

---

## Version comparison at a glance

| Feature | v1 | v2 | v3 |
|---|:---:|:---:|:---:|
| Critical refinement / devil's-advocate critique of every user input | ✅ | ✅ | ✅ |
| Elicit user's existing ideas before each step | ✅ | ✅ | ✅ |
| Study design nuances explained (RCT, quasi-experimental, and all other designs) | ✅ | ✅ | ✅ |
| Expanded database catalogue incl. AI-native tools (Consensus, Inciteful, Research Rabbit) | ✅ | ✅ | ✅ |
| MCP-tool-first search, with disclosed merits/drawbacks if none is available | ✅ | ✅ | ✅ |
| 8-framework catalogue (+ PEO, SPIDER, PCC) with citation-backed precedent search | ✅ | ✅ | ✅ |
| Expanded, verified statistics resource base + interactive decision-tree flow | ✅ | ✅ | ✅ |
| "Sources consulted" and "For further reading" disclosed on every decision | ✅ | ✅ | ✅ |
| Brainstorming 3 to 5 additional research questions | ❌ | ❌ | ✅ |
| Literature-grounded SMART objective formulation | ❌ | ✅ | ✅ |
| Gap analysis (author-stated + absence-of-evidence) | ❌ | ✅ | ✅ |
| Feasibility, realistic timeline & cost-band estimation | ❌ | ❌ | ✅ |
| Region-specific guidance (e.g., Nigeria/Africa research constraints) | ❌ | ❌ | ✅ |
| Evidence-based limitations & critique with mitigation plans | ❌ | ❌ | ✅ |
| Final deliverable: detailed, unsummarised Workflow Documentation with mandatory bibliography | ✅ | ✅ | ✅ (as a second, companion document) |
| Final deliverable: full IRB-ready study protocol (ethics, reporting-guideline selection, tense convention, mandatory bibliography, collaborator/authorship structure) | ❌ | ❌ | ✅ |
| Number of interactive workflow steps | 7 | 8 | 11 |
| Number of bundled reference files | 8 | 9 | 12 |

---

## v1, Core literature-search and study-design engine

### Why it was built
Research question development, framework selection, and academic-database search-string construction each have discipline- and syntax-specific rules that are easy to get subtly wrong. v1 makes that process both **correct** (programmatically validated) and **pedagogical**, and, as of this revision, **critical**: it no longer just accepts whatever question or framework the user proposes.

### What it includes
- **7-step interactive workflow**: study type/discipline → research question (critically refined) → framework breakdown (8-framework catalogue, precedent-cited) → search strategy (Boolean + AI-native tools) → variable/statistics mapping (interactive decision-tree) → verified reading list → final deliverable document.
- **`references/frameworks.md`**, now covering PICO, PICOC, PECO, PEO, CoCoPop, SPICE, SPIDER, and PCC.
- **`references/ai-native-search-tools.md`** *(new)*, Consensus, Inciteful, Research Rabbit, Semantic Scholar usage guidance, plus the "Google Labs" ambiguity note.
- **Four Boolean-database operator reference files** (Google Scholar, PubMed, ScienceDirect, IEEE/Scopus/WoS).
- **`references/statistical-test-mapping.md`**, now cross-checked against seven resources total, with an interactive decision-tree conversation pattern.
- **`scripts/academic_query_validator.py`**, covers nine Boolean-syntax database engines.

### Use cases v1 is well-suited for
- "I need a properly formatted, syntax-validated search string for PubMed/Scopus/Google Scholar, and I want the skill to push back if my keywords are too narrow or too broad."
- "Help me figure out whether my question needs PICO, PEO, or SPIDER, and show me if anyone else has actually used that framework for a similar question."
- "What statistical test should I use, walk me through it like an actual decision tree, not just a table."
- Any single-session task where the deliverable is a search strategy and/or a statistics plan.

### What v1 still does not do
It does not help formulate SMART objectives, does not assess feasibility or cost, does not produce a formal limitations critique, and its final deliverable is a detailed Workflow Documentation rather than an IRB-ready protocol.

---

## v2, Adding literature-grounded SMART objectives

### Why it was added
A validated search strategy and a correctly chosen, precedent-cited framework are necessary but not sufficient, a real protocol needs **objectives** that are Specific, Measurable, Achievable, Relevant, and Time-bound, with the *Relevant* criterion grounded in what the literature does and doesn't already show.

### What changed from v1
- **New Step 4, "Formulate SMART research objective(s)"** (search-strategy and variable/statistics steps renumbered accordingly; workflow grows from 7 to 8 steps).
- **New file: `references/smart-objectives.md`**, the SMART criteria breakdown, the two-track justification method (author-stated gaps vs. absence-of-evidence findings), and a worked example.
- Now also asks upfront whether the user already has candidate objectives, applying the critical-refinement principle to whatever they propose (consistent with the cross-cutting elicitation upgrade).

### Use cases v2 adds
- "I have a research question but no idea how to turn it into a proper SMART objective."
- "Help me check whether my proposed objective has already been answered, and don't just take my word that it's novel."
- "I want objectives I can defend to a supervisor or ethics committee, with the reasoning and sources shown."

### What v2 still does not do
Feasibility/cost/timeline planning, a systematic limitations critique, and a full IRB-ready protocol with dual output are still v3-exclusive.

---

## v3, Full protocol lifecycle: feasibility, limitations, and dual IRB-ready protocol + detailed workflow documentation

### Why it was added
A well-justified, search-validated, statistically sound plan still needs three more things to survive contact with an ethics committee, a funder, or co-authors: (1) an honest sense of whether it's achievable in the researcher's real timeframe and budget, (2) a transparent, evidence-based accounting of its weaknesses, and (3) a document structured the way institutions actually expect. v3 was built with resource-constrained research settings specifically in mind.

### What changed from v2
- **New Step 3, "Optional: brainstorm additional research questions."**
- **New Step 6, "Feasibility, timeline, and cost estimation,"** backed by `references/feasibility-costing.md` (Nigeria/African-context guidance included), asking country/region before any cost discussion, then timeframe and funding source, and refusing to invent currency figures.
- **New Step 9, "Limitations and evidence-based critique of study design and data,"** backed by `references/limitations-critique.md`, now also asking upfront whether the user already suspects specific weaknesses (cross-cutting elicitation upgrade applied here too).
- **Step 11 rebuilt and extended, now producing *two* separate documents**, not one: the full submission-ready **Study Protocol** (title/background, objectives, methods, feasibility/budget, limitations, ethics, the correctly named and justified reporting guideline, CONSORT, SPIRIT, STROBE, PRISMA, PRISMA-P, MOOSE, COREQ, or STARD, a CRediT-based authorship section if collaborative, and a mandatory closing Bibliography with DOI/PMID for every source) **and** a separate, detailed **Workflow Documentation**. The Workflow Documentation is explicitly *not* a condensed summary: it preserves, step by step, the full explanations, rationale, and educational content given throughout the entire eleven-step process, in the warm mentor voice, so the researcher retains a complete, readable record of the reasoning chain distinct from the institutionally-formatted protocol. It closes with the same mandatory Bibliography section. Backed by `references/study-protocol-template.md`.
- Workflow grows from 8 steps (v2) to **11 steps**; reference files grow from 8 to **10**.

### Use cases v3 adds
- "I have 6 months and limited funding, is this study actually feasible, and what will it realistically cost? Push back if my timeline is unrealistic."
- "I need an honest, defensible limitations section, not a token paragraph, and ask me what I already suspect is wrong with my design first."
- "This is a collaborative study with three co-investigators. I need both the formal protocol *and* a genuinely detailed record I can actually read back to understand what we decided and why, not a condensed summary."
- "I need to know which reporting guideline applies to my design, and I need the protocol structured around it."
- "I'm running this study in a resource-constrained setting and need realistic, non-fabricated cost/timeline guidance."

### Is v3 always the right choice?
For nearly all users, yes, v3 is a strict superset. The only reason to prefer an earlier version is wanting a lighter-weight tool for a narrower task.

---

## Full file structure (v3)

```
edutechtainment-research-librarian-v3/
├── SKILL.md                              # Main workflow definition (11 interactive steps)
├── references/
│   ├── frameworks.md                     # 8-framework catalogue + precedent-citation requirement
│   ├── ai-native-search-tools.md         # Consensus, Inciteful, Research Rabbit, Semantic Scholar, Google Labs caveat
│   ├── study-design-requirements.md      # RCT, quasi-experimental, and all other design types: mandatory criteria and nuances
│   ├── google-scholar-operators.md       # Google Scholar search syntax
│   ├── pubmed-operators.md               # PubMed / MeSH search syntax
│   ├── sciencedirect-operators.md        # ScienceDirect search syntax
│   ├── ieee-scopus-wos-operators.md      # IEEE Xplore, Scopus, Web of Science search syntax
│   ├── statistical-test-mapping.md       # Variable classification + 7-resource-verified test selection
│   ├── smart-objectives.md               # [v2+] SMART criteria + literature-gap justification method
│   ├── feasibility-costing.md            # [v3] Feasibility/timeline/cost framework, incl. African-context guidance
│   ├── limitations-critique.md           # [v3] Limitations/bias categories + mitigation strategies
│   └── study-protocol-template.md        # [v3] Full protocol structure, reporting-guideline selection, tense convention, bibliography requirement
└── scripts/
    └── academic_query_validator.py       # Syntax validator for 9 Boolean-syntax academic database query languages
```

v1 (8 reference files) and v2 (9 reference files) mirror this structure minus the version-gated files noted in the table above.

---

## Installation

1. Download the `.skill` file for the version you want (see [Quick decision guide](#quick-decision-guide)): `edutechtainment-research-librarian-v1.skill`, `edutechtainment-research-librarian-v2.skill`, or `edutechtainment-research-librarian-v3.skill`.
2. Install it through your Claude environment's skill installer.
3. Once installed, simply start describing your research task, the skill triggers automatically on relevant requests without needing to be invoked by name.

If hosting on GitHub, tag releases `v1.0.0`, `v2.0.0`, `v3.0.0` (and this revision as `v1.1.0`/`v2.1.0`/`v3.1.0`, or `v4.0.0` if you'd rather treat the cross-cutting rigour upgrades as a new major version across the board) so users can grab the exact version they want.

---

## Requirements / dependencies

- **Web search / web fetch**, required for literature verification, framework-precedent citation, gap analysis, and (v3) current cost-data lookups. The skill refuses to fabricate if these tools are unavailable, it says so rather than guesses.
- **Code execution**, required to run `academic_query_validator.py` against generated Boolean-syntax search strings.
- **Document-creation skills (`docx`, `pdf`)**, used in the final-deliverables step if Word or PDF output is requested.

---

## A note on the `description` field across versions

Claude Skills enforce a 1024-character limit on the YAML frontmatter `description` field. As features were added and the cross-cutting rigour upgrades layered in, the description had to be progressively trimmed and reworded to stay under this limit while still surfacing the skill's growing trigger vocabulary. This is a packaging constraint, not a reflection of reduced scope. The workflow body itself only ever grew across every revision.

---

## Limitations and disclaimers

- This skill is a **methodology and literature-search assistant**, not a substitute for a qualified statistician, a research ethics committee, or a professional research methodologist. Recommendations should be independently verified before submission to a funding body or ethics committee.
- Citations, framework precedents, and statistics-resource descriptions are verified at the time of the conversation via web search/fetch, always re-verify close to your actual submission date.
- Cost figures (v3) are explicitly designed to avoid fabrication: the skill will either search for real, current, region-specific data or provide a qualitative High/Medium/Low band only.
- One statistics resource requested for this update (SAGE Research Methods' "Which Stats Test" page) blocks automated access via robots.txt; its content is described only via a secondhand, disclosed characterisation from a citing library guide, not independently verified, a deliberate example of the skill's own anti-fabrication policy being applied to its own reference material.
- The skill's clinical/health-sciences framing (PICO family, CONSORT, STROBE, etc.) is general-purpose by design, but engineering, humanities, and purely qualitative researchers should expect the skill to say so plainly when a standard mnemonic framework doesn't fit, rather than forcing one.

---

## Changelog summary

| Version | Steps | Reference files | Headline additions |
|---|---|---|---|
| **v1** | 7 | 8 | Research question development (now critically refined), 8-framework selection with precedent citation, study design nuances explained for every design type, syntax-validated multi-database + AI-native search strategy with MCP-tool-first prioritisation, interactive-decision-tree variable/statistical-test mapping, verified reading list, detailed Workflow Documentation with mandatory bibliography |
| **v2** | 8 | 9 | + Literature-grounded SMART objective formulation, gap analysis (author-stated + absence-of-evidence) |
| **v3** | 11 | 12 | + Research-question brainstorming, feasibility/timeline/cost estimation (resource-constrained-setting guidance), evidence-based limitations critique, dual final output (full IRB-ready protocol with tense convention and bibliography, **and** a separate detailed Workflow Documentation, not a summary) |
| **All (rigour revision)** |, |, | Critical-refinement/devil's-advocate behaviour on every user input; expanded database catalogue incl. AI-native tools; four additional frameworks (PEO, SPIDER, PCC) with citation-backed precedent search; mandatory elicitation of user's existing ideas before every step; statistics guidance cross-checked against seven verified resources with an interactive decision-tree conversation pattern; disclosed "Sources consulted" list on every decision |
| **All (branding, voice, and rigour-completion revision)** |, |, | Renamed to EduTechTainMent Research Librarian (installable identifier: `edutechtainment-research-librarian`); one-time welcome block with creator motto and portfolio link; defined warm mentor voice with British spelling and no em dashes; "no shaming" critique ordering (reasonable framing, then evidence-based cost, then mitigation); study design nuances explained for RCT, quasi-experimental, and every other design type; explicit MCP-tool-first search process with disclosed merits/drawbacks; "For further reading" lists alongside "Sources consulted"; mandatory Bibliography with DOI/PMID in every long-form deliverable; Workflow Documentation redefined as detailed and unsummarised rather than condensed; v3's Study Protocol carved out into formal register with a deliberate tense convention |
